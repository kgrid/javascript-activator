# Basic BMI calculator module
This is an expirimental KO based off of a BMI calcualtor. This knowledge object has multiple services which can be used to access the underlying knowledge. The activator service contains functions which can be exposed through a deno activator. The CLI services exposes a simple command line interace for the functions. 

## Usage
```typescript
import { function } from "{module}";
```

## CLI
```bash
deno run ./cli/service.ts --help
```

## Test
```bash
# unit tests
deno test ./tests
```

## Format code

```bash
deno fmt **/*.ts
```

## Resources

- [Deno Website](https://deno.land)
- [Deno Style Guide](https://deno.land/std/style_guide.md)
- [Deno Gitter](https://gitter.im/denolife/Lobby)