export function welcome(inputs){
  const name = inputs.name;
  return "Welcome to Knowledge Grid, " + name;
}
